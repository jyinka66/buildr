// Paystack payment client — wraps Paystack's REST API.
// ------------------------------------------------------------------
// Used by /api/jobs/[id]/payment* routes to create + verify payments.
//
// Requires PAYSTACK_SECRET_KEY env var. When not set (dev mode), returns
// mock responses so the UI flow works end-to-end without a Paystack account.
//   - initializePayment() returns a mock authorization_url that points to
//     /api/jobs/mock-payment?ref=...  (a tiny HTML page that simulates checkout)
//   - verifyPayment() returns a synthetic "success" status immediately.
//
// All HTTP calls use AbortSignal.timeout(15_000) so a hung Paystack request
// can't block the API route indefinitely.

const PAYSTACK_BASE = 'https://api.paystack.co'
const TIMEOUT_MS = 15_000

const secretKey = process.env.PAYSTACK_SECRET_KEY || ''
export const isPaystackConfigured = Boolean(secretKey)

export interface InitializePaymentInput {
  email: string
  amountKobo: number
  reference: string
  metadata?: Record<string, unknown>
  callbackUrl?: string
}

export interface InitializePaymentResult {
  authorization_url: string
  access_code: string
  reference: string
}

export interface VerifyPaymentResult {
  status: 'success' | 'failed' | 'pending' | 'abandoned' | 'reversed'
  amount: number // kobo
  customer_email: string | null
  paid_at: string | null
  reference: string
  raw?: unknown
}

/**
 * Generate a unique Paystack payment reference for a job.
 * Format: `buildr-{jobId.slice(0,8)}-{Date.now()}` — short, stable, unique.
 */
export function generateReference(jobId: string): string {
  const id =
    (jobId || 'job')
      .replace(/[^a-zA-Z0-9]/g, '')
      .slice(0, 8) || 'job'
  return `buildr-${id}-${Date.now()}`
}

/**
 * Initialize a Paystack transaction — returns the hosted checkout URL.
 * In dev (no secret key), returns a mock URL pointing to our mock-payment page.
 */
export async function initializePayment(
  input: InitializePaymentInput,
): Promise<InitializePaymentResult> {
  if (!isPaystackConfigured) {
    const ref = input.reference
    return {
      authorization_url: `/api/jobs/mock-payment?ref=${encodeURIComponent(ref)}`,
      access_code: 'mock',
      reference: ref,
    }
  }

  const payload: Record<string, unknown> = {
    email: input.email,
    amount: Math.round(input.amountKobo),
    reference: input.reference,
    currency: 'NGN',
    metadata: input.metadata ?? {},
  }
  if (input.callbackUrl) payload.callback_url = input.callbackUrl

  const res = await fetch(`${PAYSTACK_BASE}/transaction/initialize`, {
    method: 'POST',
    headers: {
      'content-type': 'application/json',
      authorization: `Bearer ${secretKey}`,
    },
    body: JSON.stringify(payload),
    signal: AbortSignal.timeout(TIMEOUT_MS),
  })

  if (!res.ok) {
    const text = await res.text().catch(() => '')
    throw new Error(
      `paystack_initialize_failed: ${res.status} ${text.slice(0, 200)}`,
    )
  }

  const json = (await res.json()) as {
    data?: { authorization_url?: string; access_code?: string; reference?: string }
  }
  const data = json?.data ?? {}
  return {
    authorization_url: data.authorization_url ?? '',
    access_code: data.access_code ?? '',
    reference: data.reference ?? input.reference,
  }
}

/**
 * Verify a Paystack transaction by reference.
 * In dev (no secret key), returns a synthetic success response.
 */
export async function verifyPayment(
  reference: string,
): Promise<VerifyPaymentResult> {
  if (!isPaystackConfigured) {
    return {
      status: 'success',
      amount: 0,
      customer_email: null,
      paid_at: new Date().toISOString(),
      reference,
    }
  }

  const res = await fetch(
    `${PAYSTACK_BASE}/transaction/verify/${encodeURIComponent(reference)}`,
    {
      method: 'GET',
      headers: { authorization: `Bearer ${secretKey}` },
      signal: AbortSignal.timeout(TIMEOUT_MS),
    },
  )

  if (!res.ok) {
    const text = await res.text().catch(() => '')
    throw new Error(
      `paystack_verify_failed: ${res.status} ${text.slice(0, 200)}`,
    )
  }

  const json = (await res.json()) as {
    data?: {
      status?: string
      amount?: number
      reference?: string
      paid_at?: string | null
      created_at?: string | null
      customer?: { email?: string } | null
    }
  }
  const data = json?.data ?? {}
  const rawStatus = (data.status ?? 'pending').toString().toLowerCase()

  return {
    status: rawStatus as VerifyPaymentResult['status'],
    amount: Number(data.amount ?? 0),
    customer_email: data.customer?.email ?? null,
    paid_at: data.paid_at ?? data.created_at ?? null,
    reference: data.reference ?? reference,
    raw: data,
  }
}
