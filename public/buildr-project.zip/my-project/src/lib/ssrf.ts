// SSRF protection — block requests to private/internal IP ranges.
// ------------------------------------------------------------------
// Used by webhook-test, monitoring probes, and any route that fetches
// a user-supplied URL. Prevents internal network scanning (e.g. hitting
// 169.254.169.254 for cloud metadata, or localhost services).

import { lookup } from 'dns/promises'
import { isIP } from 'net'

// Private/reserved IP ranges (IPv4 + IPv6) that must NEVER be fetched.
const BLOCKED_PATTERNS = [
  // IPv4 private ranges
  /^10\./, // 10.0.0.0/8
  /^172\.(1[6-9]|2\d|3[01])\./, // 172.16.0.0/12
  /^192\.168\./, // 192.168.0.0/16
  /^127\./, // 127.0.0.0/8 (loopback)
  /^169\.254\./, // 169.254.0.0/16 (link-local + cloud metadata)
  /^0\./, // 0.0.0.0/8
  /^100\.(6[4-9]|[7-9]\d|1[01]\d|12[0-7])\./, // 100.64.0.0/10 (CGNAT)
  /^192\.0\.[01]\./, // 192.0.0.0/24, 192.0.2.0/24
  /^198\.(1[89])\./, // 198.18.0.0/15 (benchmark)
  /^203\.0\.113\./, // 203.0.113.0/24 (documentation)
  // IPv6 loopback + private
  /^::1$/, // loopback
  /^fc00:/i, // unique local
  /^fe80:/i, // link-local
  /^::ffff:127\./, // IPv4-mapped loopback
  /^::ffff:10\./, // IPv4-mapped private
  /^::ffff:192\.168\./,
]

export interface SsrfCheckResult {
  ok: boolean
  reason?: string
}

// Check a URL string for SSRF risk. Resolves the hostname and checks
// whether any resolved IP is in a blocked range.
export async function isUrlSafe(urlStr: string): Promise<SsrfCheckResult> {
  let url: URL
  try {
    url = new URL(urlStr)
  } catch {
    return { ok: false, reason: 'invalid_url' }
  }

  // Only allow http/https — no file://, gopher://, ftp://, etc.
  if (url.protocol !== 'http:' && url.protocol !== 'https:') {
    return { ok: false, reason: 'unsupported_protocol' }
  }

  const hostname = url.hostname

  // Check if hostname is a raw IP first.
  if (isIP(hostname)) {
    if (isBlockedIp(hostname)) {
      return { ok: false, reason: 'blocked_ip' }
    }
    return { ok: true }
  }

  // DNS resolve the hostname and check all resolved IPs.
  try {
    const records = await lookup(hostname, { all: true })
    for (const r of records) {
      if (isBlockedIp(r.address)) {
        return { ok: false, reason: 'blocked_ip' }
      }
    }
    return { ok: true }
  } catch {
    // DNS resolution failed — allow the fetch to proceed so the caller
    // gets a proper error (rather than a confusing SSRF message).
    return { ok: true }
  }
}

function isBlockedIp(ip: string): boolean {
  return BLOCKED_PATTERNS.some((re) => re.test(ip))
}

// Middleware-style wrapper for fetch calls. Checks the URL, then fetches.
// Throws an Error with a clear message if the URL is blocked.
export async function safeFetch(
  url: string,
  init?: RequestInit,
  opts?: { timeoutMs?: number },
): Promise<Response> {
  const check = await isUrlSafe(url)
  if (!check.ok) {
    throw new Error(`SSRF blocked: ${check.reason} (url: ${url})`)
  }
  const timeoutMs = opts?.timeoutMs ?? 15_000
  const controller = new AbortController()
  const timer = setTimeout(() => controller.abort(), timeoutMs)
  try {
    return await fetch(url, { ...init, signal: controller.signal })
  } finally {
    clearTimeout(timer)
  }
}
