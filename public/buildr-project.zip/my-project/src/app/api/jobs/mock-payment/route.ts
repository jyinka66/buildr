// GET /api/jobs/mock-payment?ref=XYZ
// ------------------------------------------------------------------
// Dev-only mock Paystack checkout page.
// Only served when PAYSTACK_SECRET_KEY is NOT set — lets the full payment
// flow work end-to-end in local dev without a real Paystack account.
//
// The page looks up the payment row by `paystack_ref`, renders a small
// "checkout" UI, and a "Pay Now" button that POSTs to
// /api/jobs/{job_id}/payment/verify to mark the payment as succeeded.
// The parent window (jobs-view) polls that same endpoint every 5s and will
// pick up the confirmed status automatically.
//
// When Paystack IS configured, this route returns 404.

import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { isPaystackConfigured } from '@/lib/paystack'

function escapeHtml(s: string): string {
  return s
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;')
}

export async function GET(req: NextRequest) {
  if (isPaystackConfigured) {
    return NextResponse.json(
      { error: 'mock_route_disabled_in_production' },
      { status: 404 },
    )
  }

  const url = new URL(req.url)
  const ref = url.searchParams.get('ref') || ''
  if (!ref) {
    return NextResponse.json({ error: 'missing_ref' }, { status: 400 })
  }

  // Look up the payment row to find job_id + amount + customer_email.
  const { data: payment } = await db
    .from('paystack_payments')
    .select('job_id, amount_kobo, currency, type, customer_email, status')
    .eq('paystack_ref', ref)
    .maybeSingle()

  const jobId = (payment?.job_id as string) || ''
  const amountKobo = Number(payment?.amount_kobo ?? 0)
  const amountNgn = (amountKobo / 100).toLocaleString(undefined, {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  })
  const currency = (payment?.currency as string) || 'NGN'
  const type = (payment?.type as string) || 'deposit'
  const customerEmail = (payment?.customer_email as string) || ''
  const alreadyPaid = payment?.status === 'success'

  const verifyUrl = jobId
    ? `/api/jobs/${encodeURIComponent(jobId)}/payment/verify`
    : ''

  const html = `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Mock Paystack Checkout — Buildr</title>
<style>
  :root { color-scheme: light dark; }
  * { box-sizing: border-box; }
  body {
    margin: 0; min-height: 100vh; display: flex; align-items: center;
    justify-content: center; padding: 24px; font-family: ui-sans-serif, system-ui,
    -apple-system, "Segoe UI", Roboto, sans-serif;
    background: linear-gradient(135deg, #0ea5e9 0%, #0284c7 100%);
  }
  .card {
    width: 100%; max-width: 420px; background: #fff; color: #0f172a;
    border-radius: 16px; padding: 28px; box-shadow: 0 20px 50px rgba(0,0,0,.25);
  }
  .logo {
    display: inline-flex; align-items: center; gap: 8px; font-weight: 700;
    font-size: 14px; color: #0284c7; margin-bottom: 4px; letter-spacing: .04em;
    text-transform: uppercase;
  }
  .dot { width: 10px; height: 10px; border-radius: 999px; background: #22c55e; }
  h1 { margin: 0 0 4px; font-size: 22px; font-weight: 700; }
  .ref { font-size: 12px; color: #64748b; margin-bottom: 22px; word-break: break-all; }
  .amount {
    font-size: 38px; font-weight: 700; margin: 0 0 4px; font-variant-numeric: tabular-nums;
  }
  .amount small { font-size: 16px; font-weight: 600; color: #64748b; margin-left: 6px; }
  .meta { color: #475569; font-size: 13px; margin-bottom: 24px; }
  .meta div { margin: 2px 0; }
  .meta b { color: #0f172a; font-weight: 600; }
  button {
    width: 100%; padding: 14px 16px; border: 0; border-radius: 10px; font-size: 15px;
    font-weight: 600; cursor: pointer; transition: background .15s ease;
  }
  .pay { background: #16a34a; color: #fff; }
  .pay:hover { background: #15803d; }
  .pay:disabled { background: #cbd5e1; color: #64748b; cursor: not-allowed; }
  .cancel { background: transparent; color: #64748b; margin-top: 10px; font-weight: 500; }
  .cancel:hover { background: #f1f5f9; color: #0f172a; }
  .status { text-align: center; margin-top: 18px; font-size: 14px; min-height: 20px; }
  .ok { color: #15803d; font-weight: 600; }
  .err { color: #b91c1c; font-weight: 600; }
  .note { margin-top: 18px; padding: 10px 12px; border-radius: 8px;
    background: #fef9c3; color: #854d0e; font-size: 12px; line-height: 1.45; }
  @media (prefers-color-scheme: dark) {
    .card { background: #0f172a; color: #e2e8f0; }
    .meta { color: #94a3b8; }
    .meta b { color: #f1f5f9; }
    .ref { color: #64748b; }
    .cancel:hover { background: #1e293b; color: #f1f5f9; }
  }
</style>
</head>
<body>
  <div class="card">
    <div class="logo"><span class="dot"></span> Mock Paystack Checkout</div>
    <h1>Pay for your ${escapeHtml(type)} payment</h1>
    <div class="ref">Reference: ${escapeHtml(ref)}</div>
    <div class="amount">₦${escapeHtml(amountNgn)}<small>${escapeHtml(currency)}</small></div>
    <div class="meta">
      ${customerEmail ? `<div>Customer: <b>${escapeHtml(customerEmail)}</b></div>` : ''}
      <div>Mode: <b>Development (mock)</b></div>
    </div>

    ${
      alreadyPaid
        ? `<div class="status ok">✓ This payment has already been confirmed.</div>
           <button class="cancel" onclick="window.close()">Close tab</button>`
        : `<button class="pay" id="payBtn" ${verifyUrl ? '' : 'disabled'}>
             Pay ₦${escapeHtml(amountNgn)}
           </button>
           <button class="cancel" onclick="window.close()">Cancel</button>
           <div class="status" id="status"></div>
           <div class="note">
             <b>Dev mode:</b> PAYSTACK_SECRET_KEY is not set, so this is a mock checkout.
             Clicking "Pay" simulates a successful transaction and marks the payment as
             confirmed — the Buildr app will detect it automatically within 5 seconds.
           </div>`
    }
  </div>

  ${
    alreadyPaid
      ? ''
      : `<script>
    const btn = document.getElementById('payBtn');
    const status = document.getElementById('status');
    const verifyUrl = ${JSON.stringify(verifyUrl)};
    const ref = ${JSON.stringify(ref)};
    btn.addEventListener('click', async () => {
      if (!verifyUrl) {
        status.className = 'status err';
        status.textContent = 'Cannot verify — missing job context.';
        return;
      }
      btn.disabled = true;
      status.className = 'status';
      status.textContent = 'Processing…';
      try {
        const res = await fetch(verifyUrl, {
          method: 'POST',
          headers: { 'content-type': 'application/json' },
          body: JSON.stringify({ reference: ref }),
          credentials: 'same-origin',
        });
        const data = await res.json().catch(() => ({}));
        if (res.ok && data.ok && data.status === 'success') {
          status.className = 'status ok';
          status.textContent = '✓ Payment successful — you can close this tab.';
          btn.textContent = 'Done';
        } else {
          status.className = 'status err';
          status.textContent = 'Verification issue: ' + (data?.error || data?.status || 'unknown');
          btn.disabled = false;
        }
      } catch (e) {
        status.className = 'status err';
        status.textContent = 'Network error: ' + (e?.message || 'unknown');
        btn.disabled = false;
      }
    });
  </script>`
  }
</body>
</html>`

  return new NextResponse(html, {
    status: 200,
    headers: {
      'content-type': 'text/html; charset=utf-8',
      'cache-control': 'no-store',
    },
  })
}
