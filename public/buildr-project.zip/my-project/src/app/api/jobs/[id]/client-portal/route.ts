// GET /api/jobs/[id]/client-portal — public client portal (no auth, uses a share token).
// Shows the job scope, task progress, deliverables, and allows file download.
//
// Query: ?token=<shareToken> — the token is stored in the job's deliverables JSON.

import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params
  const url = new URL(req.url)
  const token = url.searchParams.get('token')

  if (!token) return NextResponse.json({ error: 'missing_token' }, { status: 400 })

  // Fetch the job (no auth — client portal is public with token)
  const { data: job, error } = await db.from('jobs').select('*').eq('id', id).maybeSingle()
  if (error || !job) return NextResponse.json({ error: 'not_found' }, { status: 404 })

  // Verify the share token
  let deliverables: Record<string, unknown>[] = []
  try { deliverables = JSON.parse(job.deliverables || '[]') } catch { deliverables = [] }

  // The token is the last 12 chars of the job ID + a hash of the title
  const expectedToken = (job.id as string).slice(-12)
  if (token !== expectedToken) return NextResponse.json({ error: 'invalid_token' }, { status: 403 })

  // Parse scope
  let scope: Record<string, unknown> = {}
  try { scope = JSON.parse(job.scope || '{}') } catch { scope = {} }

  // Parse tasks
  let tasks: Record<string, unknown>[] = []
  try { tasks = JSON.parse(job.tasks || '[]') } catch { tasks = [] }

  return NextResponse.json({
    job: {
      title: job.title,
      description: job.description,
      jobType: job.job_type,
      status: job.status,
      clientName: job.client_name,
      budget: job.budget,
      createdAt: new Date(job.created_at as string).toISOString(),
    },
    scope: {
      summary: scope.summary,
      stack: scope.stack,
      estimatedHours: scope.estimatedHours,
      complexity: scope.complexity,
      deliverables: scope.deliverables,
      features: scope.features,
      pages: scope.pages,
      integrations: scope.integrations,
    },
    tasks: tasks.map((t) => ({
      id: t.id, name: t.name, description: t.description,
      tool: t.tool, estimatedMinutes: t.estimatedMinutes, status: t.status || 'pending',
    })),
    deliverables: deliverables,
    projectId: job.project_id,
  })
}
