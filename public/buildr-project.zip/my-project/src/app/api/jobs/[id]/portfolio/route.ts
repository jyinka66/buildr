// GET /api/jobs/[id]/portfolio — generates a public portfolio entry for a completed job.
// Returns: job details + scope + client review (if any) + tech stack + timeline.
// This is public (no auth) so it can be shared as a portfolio link.

import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params

  // Fetch the job — only return portfolio data if it's delivered
  const { data: job, error } = await db.from('jobs').select('*').eq('id', id).maybeSingle()
  if (error || !job) return NextResponse.json({ error: 'not_found' }, { status: 404 })

  // Only show delivered or reviewing jobs in portfolio
  if (!['delivered', 'reviewing'].includes(job.status as string)) {
    return NextResponse.json({ error: 'job_not_delivered' }, { status: 400 })
  }

  let scope: Record<string, unknown> = {}
  try { scope = JSON.parse(job.scope || '{}') } catch { scope = {} }

  let deliverables: Record<string, unknown>[] = []
  try { deliverables = JSON.parse(job.deliverables || '[]') } catch { deliverables = [] }

  return NextResponse.json({
    portfolio: {
      title: job.title,
      description: job.description,
      jobType: job.job_type,
      clientName: job.client_name || 'Anonymous Client',
      status: job.status,
      budget: job.budget,
      createdAt: new Date(job.created_at as string).toISOString(),
      scope: {
        summary: scope.summary,
        stack: scope.stack,
        estimatedHours: scope.estimatedHours,
        complexity: scope.complexity,
        deliverables: scope.deliverables,
        features: scope.features,
      },
      deliverables: deliverables.map((d) => ({
        type: d.type,
        name: d.name || d.path,
        url: d.url,
      })),
      projectId: job.project_id,
    },
  })
}

// POST — allow client to leave a review + rating
export async function POST(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params
  const body = await req.json()
  const { rating, review, clientName } = body

  if (!rating || rating < 1 || rating > 5) {
    return NextResponse.json({ error: 'rating must be 1-5' }, { status: 400 })
  }

  // Store the review in the job's scope (as a nested field)
  const { data: job, error: jobErr } = await db.from('jobs').select('scope').eq('id', id).maybeSingle()
  if (jobErr || !job) return NextResponse.json({ error: 'not_found' }, { status: 404 })

  let scope: Record<string, unknown> = {}
  try { scope = JSON.parse(job.scope || '{}') } catch { scope = {} }

  scope.clientReview = { rating, review, clientName: clientName || 'Anonymous', date: new Date().toISOString() }

  const { error: updateErr } = await db.from('jobs').update({ scope: JSON.stringify(scope) }).eq('id', id)

  if (updateErr) return NextResponse.json({ error: updateErr.message }, { status: 500 })

  return NextResponse.json({ ok: true, review: scope.clientReview })
}
