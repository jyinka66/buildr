// POST /api/jobs/[id]/payment/verify — verify a Paystack payment.
// ------------------------------------------------------------------
// Body: { reference: string }
// Auth:  requireSessionUser() + job ownership.
// Calls Paystack's verify endpoint, updates the paystack_payments row,
// and — if it's a milestone payment that succeeded — marks the milestone's
// tasks as completed.
// Returns: { ok, status, amount, paidAt }

import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireSessionUser } from '@/lib/session'
import { rateLimit, rateLimitedResponse } from '@/lib/rate-limit'
import { verifyPayment } from '@/lib/paystack'

interface VerifyBody {
  reference?: string
}

export async function POST(
  req: NextRequest,
  ctx: { params: Promise<{ id: string }> },
) {
  let user
  try {
    user = await requireSessionUser()
  } catch (err) {
    if ((err as { status?: number }).status === 401) {
      return NextResponse.json({ error: 'unauthorized' }, { status: 401 })
    }
    throw err
  }

  const rl = rateLimit(`payment-verify:${user.id}`, {
    limit: 30,
    windowMs: 60_000,
  })
  if (!rl.ok) return rateLimitedResponse(rl.resetMs)

  const { id } = await ctx.params
  const body = (await req.json().catch(() => ({}))) as VerifyBody
  const reference = typeof body.reference === 'string' ? body.reference.trim() : ''
  if (!reference) {
    return NextResponse.json({ error: 'missing_reference' }, { status: 400 })
  }

  // Verify job ownership.
  const { data: job, error: jobErr } = await db
    .from('jobs')
    .select('id, owner_id, tasks')
    .eq('id', id)
    .eq('owner_id', user.id)
    .maybeSingle()
  if (jobErr || !job) {
    return NextResponse.json({ error: 'not_found' }, { status: 404 })
  }

  // Find the payment row by reference + job_id.
  const { data: payment, error: paymentErr } = await db
    .from('paystack_payments')
    .select('*')
    .eq('paystack_ref', reference)
    .eq('job_id', id)
    .maybeSingle()
  if (paymentErr || !payment) {
    return NextResponse.json({ error: 'payment_not_found' }, { status: 404 })
  }

  // Already verified previously — short-circuit with stored state.
  if (payment.status === 'success' || payment.status === 'failed') {
    return NextResponse.json({
      ok: true,
      status: payment.status,
      amount: Number(payment.amount_kobo ?? 0),
      paidAt: payment.paid_at
        ? new Date(payment.paid_at as string).toISOString()
        : null,
      cached: true,
    })
  }

  // ── Call Paystack's verify endpoint (real or mock) ────────────────────
  let verified
  try {
    verified = await verifyPayment(reference)
  } catch (err) {
    return NextResponse.json(
      {
        error: 'paystack_verify_failed',
        message: err instanceof Error ? err.message : 'unknown',
      },
      { status: 502 },
    )
  }

  const isSuccess = verified.status === 'success'
  const paidAt = verified.paid_at || new Date().toISOString()

  // ── Update the payment row ────────────────────────────────────────────
  await db
    .from('paystack_payments')
    .update({
      status: isSuccess ? 'success' : 'failed',
      paid_at: isSuccess ? paidAt : null,
    })
    .eq('id', payment.id)

  // ── If it's a successful milestone payment, mark tasks completed ─────
  if (
    isSuccess &&
    payment.type === 'milestone' &&
    typeof payment.milestone_index === 'number'
  ) {
    let tasks: Record<string, unknown>[] = []
    try {
      tasks = JSON.parse(job.tasks || '[]')
    } catch {
      tasks = []
    }
    const start = payment.milestone_index * 3
    const end = start + 3
    for (let i = start; i < Math.min(end, tasks.length); i++) {
      tasks[i] = { ...tasks[i], status: 'completed' }
    }
    await db.from('jobs').update({ tasks: JSON.stringify(tasks) }).eq('id', id)
  }

  return NextResponse.json({
    ok: true,
    status: verified.status,
    amount: verified.amount,
    paidAt: isSuccess ? paidAt : null,
  })
}
