'use client'

// Buildr — single user-visible route ("/").
// Renders the global shell + the active view from the Zustand store.

import React, { useEffect } from 'react'
import { useBuilder } from '@/lib/store'
import { AppHeader, AppFooter } from '@/components/builder/app-shell'
import { AppSidebar, AppTopBar } from '@/components/builder/app-sidebar'
import { LandingView } from '@/components/builder/landing-view'
import DashboardView from '@/components/builder/dashboard-view'
import { BuilderWorkspace } from '@/components/builder/builder-workspace'
import { SettingsView } from '@/components/builder/settings-view'
import BusinessLaunchView from '@/components/builder/business-launch-view'
import JobsView from '@/components/builder/jobs-view'
import GodModeView from '@/components/builder/god-mode-view'
import BillingView from '@/components/builder/billing-view'
import MarketingView from '@/components/builder/marketing-view'
import SupportView from '@/components/builder/support-view'
import OperationsView from '@/components/builder/operations-view'
import NotificationsView from '@/components/builder/notifications-view'
import ApiKeysView from '@/components/builder/api-keys-view'
import WebhooksView from '@/components/builder/webhooks-view'
import WorkspacesView from '@/components/builder/workspaces-view'
import AdminView from '@/components/builder/admin-view'
import OnboardingView from '@/components/builder/onboarding-view'
import AnalyticsView from '@/components/builder/analytics-view'
import { SharedProjectView } from '@/components/builder/shared-project-view'
import { AuthDialog } from '@/components/builder/auth-dialog'
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert'
import { Button } from '@/components/ui/button'
import { Loader2, TriangleAlert, Wrench } from 'lucide-react'

export default function Home() {
  const view = useBuilder((s) => s.view)
  const boot = useBuilder((s) => s.boot)
  const booted = useBuilder((s) => s.booted)
  const bootError = useBuilder((s) => s.bootError)
  const session = useBuilder((s) => s.session)
  const openAuth = useBuilder((s) => s.openAuth)

  useEffect(() => {
    if (!booted) boot()
  }, [booted, boot])

  // Hidden admin login: visiting /?admin=1 opens the auth dialog.
  useEffect(() => {
    if (typeof window === 'undefined') return
    const params = new URLSearchParams(window.location.search)
    if (params.get('admin') === '1' && !session) {
      openAuth('login')
      window.history.replaceState({}, '', '/')
    }
  }, [session, openAuth])

  // Screenshot gallery mode: visiting /?screenshots=1 shows the captured
  // dashboard + builder images directly. Used for preview-panel viewing.
  const [screenshotMode, setScreenshotMode] = React.useState(false)
  React.useEffect(() => {
    if (typeof window !== 'undefined') {
      const params = new URLSearchParams(window.location.search)
      setScreenshotMode(params.get('screenshots') === '1')
    }
  }, [])

  // Maintenance mode banner.
  const [maintenance, setMaintenance] = React.useState(false)
  React.useEffect(() => {
    fetch('/api/status').then((r) => r.json()).then((d) => { if (d.maintenance) setMaintenance(true) }).catch(() => {})
  }, [])

  const showSetupScreen = bootError && view !== 'landing'

  // Screenshot gallery mode — early return after all hooks.
  if (screenshotMode) {
    return (
      <div className="min-h-screen bg-zinc-950 px-4 py-8 text-white md:px-8">
        <div className="mx-auto max-w-5xl">
          <h1 className="mb-2 text-2xl font-bold tracking-tight">Buildr — Screenshots</h1>
          <p className="mb-8 text-sm text-zinc-400">
            Captured previews of the dashboard and builder workspace with an AI-generated chat app.
          </p>
          <div className="space-y-10">
            <div>
              <h2 className="mb-3 text-lg font-semibold text-emerald-400">1. Dashboard</h2>
              <img src="/screenshots/dashboard.png" alt="Buildr Dashboard" className="w-full rounded-xl border border-zinc-800 shadow-2xl" />
            </div>
            <div>
              <h2 className="mb-3 text-lg font-semibold text-emerald-400">2. Builder — Chat App Preview</h2>
              <img src="/screenshots/builder.png" alt="Buildr Builder with Chat App" className="w-full rounded-xl border border-zinc-800 shadow-2xl" />
            </div>
            <div>
              <h2 className="mb-3 text-lg font-semibold text-emerald-400">3. Builder — Rendered Chat UI (viewport)</h2>
              <img src="/screenshots/builder-preview.png" alt="Chat App UI in Preview" className="w-full rounded-xl border border-zinc-800 shadow-2xl" />
            </div>
          </div>
          <p className="mt-8 text-center text-xs text-zinc-500">
            Visit <code className="rounded bg-zinc-900 px-1.5 py-0.5 text-zinc-300">/</code> for the live app.
          </p>
        </div>
      </div>
    )
  }

  // Determine which layout to use:
  // - "full" = full screen, no header/footer/sidebar (builder, shared, onboarding)
  // - "landing" = top header + content + footer (logged-out landing page)
  // - "sidebar" = left sidebar + slim top bar + content (all authenticated page views)
  const isFullScreenView = view === 'builder' || view === 'shared' || view === 'onboarding'
  const isLandingView = view === 'landing' || !session

  // Render the active view content.
  function renderView() {
    if (showSetupScreen) {
      return (
        <div className="mx-auto max-w-3xl px-4 py-16">
          <Alert variant="destructive">
            <TriangleAlert className="h-4 w-4" />
            <AlertTitle>Couldn&apos;t start Buildr</AlertTitle>
            <AlertDescription className="mt-2">
              <p className="mb-3">{bootError}</p>
              <Button size="sm" onClick={() => boot()} variant="outline">
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Retry
              </Button>
            </AlertDescription>
          </Alert>
        </div>
      )
    }
    switch (view) {
      case 'landing': return <LandingView />
      case 'dashboard': return <DashboardView />
      case 'builder': return <BuilderWorkspace />
      case 'settings': return <SettingsView />
      case 'business': return <BusinessLaunchView />
      case 'jobs': return <JobsView />
      case 'godmode': return <GodModeView />
      case 'billing': return <BillingView />
      case 'marketing': return <MarketingView />
      case 'support': return <SupportView />
      case 'ops': return <OperationsView />
      case 'analytics': return <AnalyticsView />
      case 'notifications': return <NotificationsView />
      case 'api-keys': return <ApiKeysView />
      case 'webhooks': return <WebhooksView />
      case 'workspaces': return <WorkspacesView />
      case 'admin': return <AdminView />
      case 'onboarding': return <OnboardingView />
      case 'shared': return <SharedProjectView />
      default: return <LandingView />
    }
  }

  // ── Full-screen views (builder, shared, onboarding) ─────────────
  if (isFullScreenView) {
    return (
      <div className="flex min-h-screen flex-col bg-background">
        {maintenance && (
          <div className="flex items-center justify-center gap-2 bg-amber-500 px-4 py-2 text-center text-sm font-medium text-white">
            <Wrench className="h-4 w-4" />
            Buildr is in maintenance mode. Read-only access is available.
          </div>
        )}
        <main className="min-h-0 flex-1">
          {renderView()}
        </main>
        <AuthDialog />
      </div>
    )
  }

  // ── Landing layout (logged out) ─────────────────────────────────
  if (isLandingView) {
    return (
      <div className="flex min-h-screen flex-col bg-background">
        {maintenance && (
          <div className="flex items-center justify-center gap-2 bg-amber-500 px-4 py-2 text-center text-sm font-medium text-white">
            <Wrench className="h-4 w-4" />
            Buildr is in maintenance mode. Read-only access is available.
          </div>
        )}
        <AppHeader />
        <main className="flex-1">
          {renderView()}
        </main>
        <AppFooter />
        <AuthDialog />
      </div>
    )
  }

  // ── Sidebar layout (authenticated page views) ───────────────────
  return (
    <div className="flex min-h-screen bg-background">
      {maintenance && (
        <div className="flex items-center justify-center gap-2 bg-amber-500 px-4 py-2 text-center text-sm font-medium text-white">
          <Wrench className="h-4 w-4" />
          Buildr is in maintenance mode. Read-only access is available.
        </div>
      )}
      <AppSidebar />
      <div className="flex min-w-0 flex-1 flex-col">
        <AppTopBar />
        <main className="min-h-0 flex-1 overflow-auto">
          {renderView()}
        </main>
      </div>
      <AuthDialog />
    </div>
  )
}
