// Buildr Collaboration Service — real-time WebSocket server on port 3004.
// ------------------------------------------------------------------
// Enables multiple users to edit a project simultaneously. Features:
//   - Presence: see who's online and where their cursor is
//   - File edits: broadcast file changes to all connected editors
//   - Cursor positions: show other users' cursors in the code editor
//   - Chat: in-editor chat between collaborators
//
// This is a standalone Bun + Socket.IO service. The Next.js frontend
// connects via io("/?XTransformPort=3004") (through the gateway).
//
// Rooms are keyed by projectId. Authentication is via the NextAuth JWT
// session token, verified against NEXTAUTH_SECRET. In dev mode
// (NODE_ENV !== production), connections are accepted without token
// verification for local testing.
//
// SECURITY:
//   - CORS is restricted to the configured ALLOWED_ORIGINS (or the
//     gateway origin in production) — never '*'.
//   - JWT is verified with jose (if available) or jsonwebtoken.
//   - The userId is extracted from the JWT, not the query string.

import { Server } from 'socket.io'
import { jwtVerify } from 'jose'

const PORT = 3004

// ---- Security config -----------------------------------------------------
const isProduction = process.env.NODE_ENV === 'production'
const NEXTAUTH_SECRET = process.env.NEXTAUTH_SECRET || ''

// SECURITY: in production, the secret MUST be set.
if (isProduction && !NEXTAUTH_SECRET) {
  console.error('[Collab] FATAL: NEXTAUTH_SECRET is required in production.')
  process.exit(1)
}

// CORS: restrict to the app origin(s). Default to the gateway in dev.
const ALLOWED_ORIGINS = (process.env.ALLOWED_ORIGINS || '')
  .split(',')
  .map((s) => s.trim())
  .filter(Boolean)
// In dev, allow localhost:3000 if no origins configured.
const corsOrigins = ALLOWED_ORIGINS.length > 0
  ? ALLOWED_ORIGINS
  : isProduction
    ? [] // production REQUIRES explicit config
    : ['http://localhost:3000']

if (isProduction && ALLOWED_ORIGINS.length === 0) {
  console.error('[Collab] FATAL: ALLOWED_ORIGINS must be set in production.')
  process.exit(1)
}

// ---- JWT verification ----------------------------------------------------
const secretKey = new TextEncoder().encode(NEXTAUTH_SECRET || 'buildr-dev-secret-change-in-production')

async function verifyToken(token: string): Promise<{ userId?: string; email?: string } | null> {
  if (!NEXTAUTH_SECRET) return null
  try {
    const { payload } = await jwtVerify(token, secretKey, {
      algorithms: ['HS256'],
    })
    return {
      userId: (payload as Record<string, unknown>).id as string | undefined,
      email: (payload as Record<string, unknown>).email as string | undefined,
    }
  } catch {
    return null
  }
}

// ---- Supabase client (for project membership checks) --------------------
import { createClient } from '@supabase/supabase-js'

const supabaseUrl = process.env.SUPABASE_URL || ''
const supabaseAnonKey = process.env.SUPABASE_ANON_KEY || ''
const supabase = supabaseUrl && supabaseAnonKey
  ? createClient(supabaseUrl, supabaseAnonKey)
  : null

// Verify the user is authorized to access the project room.
// Checks: project ownership OR project membership with edit role.
async function verifyProjectAccess(
  userId: string,
  projectId: string,
): Promise<boolean> {
  if (!supabase) return true // dev mode without Supabase — allow
  try {
    // Check ownership.
    const { data: project } = await supabase
      .from('projects')
      .select('owner_id')
      .eq('id', projectId)
      .maybeSingle()
    if (project && project.owner_id === userId) return true

    // Check membership.
    const { data: membership } = await supabase
      .from('project_members')
      .select('id')
      .eq('project_id', projectId)
      .eq('user_id', userId)
      .maybeSingle()
    return Boolean(membership)
  } catch {
    return false
  }
}

interface User {
  id: string
  email: string
  name: string | null
  color: string // cursor color
}

interface CursorPosition {
  fileId: string
  path: string
  line: number
  column: number
}

interface FileEdit {
  path: string
  content: string
  userId: string
  timestamp: number
}

interface ChatMessage {
  userId: string
  userName: string
  text: string
  timestamp: number
}

// Colors for user cursors (emerald/teal palette to match the brand).
const CURSOR_COLORS = [
  '#059669', '#0d9488', '#0891b2', '#0284c7',
  '#7c3aed', '#c026d3', '#db2777', '#dc2626',
  '#ea580c', '#ca8a04', '#65a30d', '#16a34a',
]
let colorIndex = 0

// In-memory state (per server instance).
const rooms = new Map<string, {
  users: Map<string, User>
  cursors: Map<string, CursorPosition>
  edits: FileEdit[]
  chat: ChatMessage[]
}>()

function getRoom(projectId: string) {
  if (!rooms.has(projectId)) {
    rooms.set(projectId, {
      users: new Map(),
      cursors: new Map(),
      edits: [],
      chat: [],
    })
  }
  return rooms.get(projectId)!
}

const io = new Server(PORT, {
  cors: {
    origin: corsOrigins.length > 0 ? corsOrigins : false,
    methods: ['GET', 'POST'],
    credentials: true,
  },
  path: '/',
})

// Auth middleware — verify the session token before allowing connection.
// In production, the JWT MUST be verified against NEXTAUTH_SECRET.
// In dev, connections are accepted with a userId + projectId (for testing).
io.use(async (socket, next) => {
  const projectId = socket.handshake.query.projectId as string
  const token = socket.handshake.auth?.token as string || socket.handshake.query.token as string

  if (!projectId) {
    return next(new Error('projectId is required'))
  }

  // In production, verify the JWT and extract the userId.
  if (isProduction) {
    if (!token) {
      return next(new Error('Authentication required in production'))
    }
    const claims = await verifyToken(token)
    if (!claims || !claims.userId) {
      return next(new Error('Invalid or expired token'))
    }
    // SECURITY: verify the user is authorized to access this project
    // (owner or member). Prevents unauthorized users from joining
    // project rooms and injecting events.
    const hasAccess = await verifyProjectAccess(claims.userId, projectId)
    if (!hasAccess) {
      return next(new Error('Access denied: you are not a member of this project'))
    }
    // Use the verified userId from the JWT, not the query string.
    ;(socket.data as Record<string, unknown>).userId = claims.userId
    ;(socket.data as Record<string, unknown>).email = claims.email || 'unknown@buildr.dev'
    return next()
  }

  // Dev mode: accept connections with projectId (token optional).
  const userId = (socket.handshake.query.userId as string) || 'dev-user'
  ;(socket.data as Record<string, unknown>).userId = userId
  next()
})

io.on('connection', (socket) => {
  const projectId = socket.handshake.query.projectId as string
  // Use the verified userId from the JWT (set in the auth middleware),
  // not the query string (which is untrusted in production).
  const userId = (socket.data as Record<string, unknown>).userId as string || 'anonymous'
  const email = ((socket.data as Record<string, unknown>).email as string) || (socket.handshake.query.email as string) || 'anonymous@buildr.dev'
  const name = (socket.handshake.query.name as string) || null

  if (!projectId) {
    socket.disconnect()
    return
  }

  const color = CURSOR_COLORS[colorIndex++ % CURSOR_COLORS.length]
  const user: User = { id: userId, email, name, color }
  const room = getRoom(projectId)

  // Join the project room.
  socket.join(projectId)
  room.users.set(socket.id, user)

  console.log(`[Collab] ${email} joined project ${projectId} (${room.users.size} users online)`)

  // Send current state to the new user.
  socket.emit('room:state', {
    users: Array.from(room.users.entries()).map(([sid, u]) => ({ socketId: sid, ...u })),
    cursors: Array.from(room.cursors.entries()).map(([sid, c]) => ({ socketId: sid, ...c })),
    recentChat: room.chat.slice(-20),
  })

  // Broadcast user joined.
  socket.to(projectId).emit('user:joined', { socketId: socket.id, ...user })

  // Cursor position update.
  socket.on('cursor:move', (pos: CursorPosition) => {
    room.cursors.set(socket.id, pos)
    socket.to(projectId).emit('cursor:move', { socketId: socket.id, user, position: pos })
  })

  // File edit broadcast.
  socket.on('file:edit', (edit: FileEdit) => {
    room.edits.push({ ...edit, timestamp: Date.now() })
    // Keep last 100 edits.
    if (room.edits.length > 100) room.edits = room.edits.slice(-100)
    socket.to(projectId).emit('file:edit', { ...edit, user, socketId: socket.id })
  })

  // File selection (which file the user is viewing).
  socket.on('file:select', (data: { path: string }) => {
    socket.to(projectId).emit('file:select', { socketId: socket.id, user, path: data.path })
  })

  // Chat message.
  socket.on('chat:message', (data: { text: string }) => {
    const msg: ChatMessage = {
      userId,
      userName: name || email,
      text: data.text,
      timestamp: Date.now(),
    }
    room.chat.push(msg)
    if (room.chat.length > 200) room.chat = room.chat.slice(-200)
    io.to(projectId).emit('chat:message', msg)
  })

  // Typing indicator.
  socket.on('chat:typing', () => {
    socket.to(projectId).emit('chat:typing', { socketId: socket.id, user })
  })

  // Disconnect.
  socket.on('disconnect', () => {
    room.users.delete(socket.id)
    room.cursors.delete(socket.id)
    socket.to(projectId).emit('user:left', { socketId: socket.id })
    console.log(`[Collab] ${email} left project ${projectId} (${room.users.size} users online)`)
  })
})

console.log(`Buildr Collaboration Service running on port ${PORT}`)
console.log(`  Connect via: io("/?XTransformPort=3004&projectId=<id>&userId=<id>&email=<email>")`)
